#ifndef EC_BOARD_H
#define EC_BOARD_H

#include "ec_inputs.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

void ec_board_enter_safe_state(void);
void ec_board_poll_inputs(uint32_t now_ms);
ec_input_snapshot_t ec_board_read_inputs(void);
void ec_board_uart_start_rx(void);
/* Transmit a raw byte buffer (binary frame) on the control UART. */
void ec_board_uart_transmit(const uint8_t *data, size_t length);

/* P0-FIX: UART RX ring buffer interface for ISR -> main-loop decoupling.
 * ISR writes bytes; main loop reads and processes them serially. */
bool ec_board_uart_rx_available(void);
uint8_t ec_board_uart_rx_read(void);

#endif
