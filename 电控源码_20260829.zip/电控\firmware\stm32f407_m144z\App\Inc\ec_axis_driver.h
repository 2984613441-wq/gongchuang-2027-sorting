#ifndef EC_AXIS_DRIVER_H
#define EC_AXIS_DRIVER_H

/* Production pick-place executor (stm32-state-machine-pseudocode.md sec. 2
 * "AxisDriver" + sec. 6 "EXECUTE_PICK_PLACE").
 *
 * This is a polled state machine that drives the fixed 7-step pick-place
 * sequence through the existing `ec_step_port_*` (PWM + counted steps) and
 * `ec_servo_port_*` (single Z lift servo) ports. It does NOT depend on the diagnostic
 * `ec_step_test` / `ec_motion_test_*` machinery; both share only the port
 * layer, and the "one counted move at a time" invariant is enforced by the
 * port's own re-entry guard (P2-5).
 *
 * NOTE: the per-move axis/direction/step-count are supplied by the caller
 * (they are the product of the pixel->steps coordinate mapping). The
 * transmission is now fixed (20-tooth GT2 pulley = 40 mm/rev) and the A4988
 * microstepping is tentatively 1/16 -> 80 steps/mm, held in
 * EC_AXIS_STEPS_PER_MM_X/Y below. The move frequency and servo pulse widths
 * are still placeholders, not calibrated.
 */

#include "ec_step_test.h"

#include <stdbool.h>
#include <stdint.h>

/* --- Config constants ---
 * steps_per_mm: X/Y drive a 20-tooth GT2 pulley (2 mm pitch) = 40 mm/rev with
 * a 200-full-step 17HS4401. At 1/16 microstepping (3200 steps/rev):
 *     3200 / 40 = 80 steps/mm.
 * If the A4988 MS1-3 jumpers change microstepping, update BOTH constants
 * together (see the A4988 parameter memo). */
#define EC_AXIS_STEPS_PER_MM_X UINT32_C(80)
#define EC_AXIS_STEPS_PER_MM_Y UINT32_C(80)
/* Move frequency is still a placeholder, not calibrated. */
#define EC_AXIS_MOVE_FREQUENCY_HZ UINT32_C(500)
/* Single Z-axis lift servo (DS3120MG). It is the ONLY servo: lowering the arm
 * opens the claw, raising it closes the claw (one-servo linkage, no separate
 * gripper servo). Pulse widths are PLACEHOLDERS, not calibrated. */
#define EC_AXIS_Z_UP_US UINT16_C(1900)     /* raised = claw closed */
#define EC_AXIS_Z_DOWN_US UINT16_C(1000)   /* lowered = claw open */
#define EC_AXIS_SERVO_SETTLE_MS UINT32_C(200)
/* Counted-move timeout margin, mirroring ec_step_test.c. */
#define EC_AXIS_MOVE_TIMEOUT_MARGIN_MS UINT32_C(1000)

typedef enum {
    EC_AXIS_RESULT_OK = 0,
    EC_AXIS_RESULT_BUSY,
    EC_AXIS_RESULT_INVALID_PARAM,
    EC_AXIS_RESULT_INHIBITED,
    EC_AXIS_RESULT_TIMEOUT,
    EC_AXIS_RESULT_ABORTED,
    EC_AXIS_RESULT_PORT_FAIL
} ec_axis_result_t;

typedef enum {
    EC_AXIS_STATE_IDLE = 0,
    EC_AXIS_STATE_MOVING,
    EC_AXIS_STATE_GRIPPING,
    EC_AXIS_STATE_DONE,
    EC_AXIS_STATE_FAULT
} ec_axis_state_t;

typedef enum {
    EC_AXIS_STEP_MOVE = 0,
    EC_AXIS_STEP_MOVE_XY,
    EC_AXIS_STEP_Z_SERVO
} ec_axis_step_kind_t;

/* One step of the pick-place program: a single-axis counted move (X/Y), a
 * simultaneous dual-axis counted move (X+Y), or the single Z-axis lift servo
 * command (lower = claw open, raise = claw close). */
typedef struct {
    ec_axis_step_kind_t kind;
    ec_axis_t axis;             /* MOVE only */
    ec_direction_t direction;   /* MOVE only; MOVE_XY: X direction */
    uint32_t steps;             /* MOVE only; MOVE_XY: X steps, 1..EC_STEP_MAX_STEPS */
    ec_direction_t y_direction; /* MOVE_XY only: Y direction */
    uint32_t y_steps;           /* MOVE_XY only: Y steps, 1..EC_STEP_MAX_STEPS */
    uint16_t servo_pulse_us;    /* Z_SERVO only */
} ec_axis_step_t;

/* Fixed 7-step program, single-servo linkage (lower = claw open, raise = claw
 * close). Each XY waypoint is one simultaneous dual-axis move (MOVE_XY):
 *   0 MOVE_XY HOME->PICK, 1 Z down (open), 2 Z up (close = grab),
 *   3 MOVE_XY PICK->PLACE, 4 Z down (open = release), 5 Z up (close = ready),
 *   6 MOVE_XY PLACE->HOME. */
#define EC_AXIS_PICK_PLACE_STEP_COUNT 7U

typedef struct {
    ec_axis_step_t step[EC_AXIS_PICK_PLACE_STEP_COUNT];
} ec_axis_pick_place_t;

void ec_axis_driver_init(void);
ec_axis_result_t ec_axis_driver_self_test(void);
ec_axis_result_t ec_axis_driver_start_pick_place(
    const ec_axis_pick_place_t *program);
ec_axis_result_t ec_axis_driver_poll(uint32_t now_ms, uint16_t active_inputs);
void ec_axis_driver_stop(void);
ec_axis_state_t ec_axis_driver_state(void);
ec_axis_result_t ec_axis_driver_result(void);
/* Number of completed program steps (0..EC_AXIS_PICK_PLACE_STEP_COUNT). This
 * is the observable progress fed to the 15-second deadline rule; each
 * completed move increments it. */
uint32_t ec_axis_driver_progress(void);

/* Convert a signed 0.1mm coordinate (the x_mm10 / y_mm10 carried by ITEM_TASK)
 * to an absolute step count for the axis, using EC_AXIS_STEPS_PER_MM_X/Y.
 * The sign is dropped here; the caller derives EC_DIRECTION_* from it (that
 * mapping needs the homing convention, which is not frozen yet). Returns 0 for
 * an axis other than X/Y. */
uint32_t ec_axis_mm10_to_steps(ec_axis_t axis, int16_t mm10);

#endif
