#include "ec_board_stm32.h"

#include "ec_app.h"
#include "ec_barrier_test.h"
#include "ec_board.h"
#include "ec_diag.h"
#include "ec_group_test.h"
#include "ec_inputs.h"
#include "ec_safety_adapter.h"
#include "ec_servo_test.h"
#include "ec_step_test.h"

#include <stddef.h>
#include <string.h>

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim8;
extern TIM_HandleTypeDef htim10;
extern TIM_HandleTypeDef htim11;
extern UART_HandleTypeDef huart2;

/* Step-timer counting clock = 100 kHz (HSI 16 MHz / (PSC+1=160), PSC=159).
 * Coupled to main.c SystemClock_Config + MX_TIMx_Init: if the system clock or
 * PSC changes, this value must be updated or the step frequency shifts. */
#define EC_STEP_TIMER_HZ UINT32_C(100000)

static ec_input_filter_t input_filter;
static ec_input_snapshot_t input_snapshot;
static uint8_t input_filter_initialized;

/* P0-FIX: UART RX ring buffer for ISR -> main-loop decoupling.
 * ISR writes, main loop reads. Fixed capacity (64 bytes, power of 2).
 * head/tail are volatile; mask arithmetic handles wrap without branches. */
#define UART_RX_RING_SIZE 64U
#define UART_RX_RING_MASK (UART_RX_RING_SIZE - 1U)
static uint8_t uart_rx_ring[UART_RX_RING_SIZE];
static volatile uint32_t uart_rx_head;  /* ISR writes here */
static volatile uint32_t uart_rx_tail;  /* main loop reads here */
static uint8_t uart_main_rx_byte;       /* single-byte staging for HAL */

/* UART RX single-byte staging buffer. Written by HAL's UART_Receive_IT and
 * read back in ec_board_uart_rx_callback (via HAL_UART_RxCpltCallback), both
 * in the UART ISR context; the main loop never touches it. No ISR<->main-loop
 * race, so unlike counted_axis below it does not need volatile. */
/* Shared between the TIM update ISR (ec_step_port_on_timer_period /
 * ec_motion_test_on_counted_done) and the main-loop poll: must be volatile
 * so -O2/-O3 does not cache them in registers and freeze STEP_REMAIN / DONE.
 * Two stepper axes (X/Y) can run counted moves simultaneously; the arrays are
 * indexed by counted_slot() (X=0, Y=1) and counted_active_mask tracks which
 * axes are active (bit 0 = X, bit 1 = Y). */
static volatile uint32_t counted_remaining[2U];
static volatile uint32_t counted_total[2U];
static volatile uint8_t counted_active_mask;

static uint16_t read_raw_inputs(void)
{
    uint16_t raw = 0U;

#define EC_READ_HIGH(bit, name)                                               \
    do {                                                                      \
        if (HAL_GPIO_ReadPin(name##_GPIO_Port, name##_Pin) == GPIO_PIN_SET) { \
            raw |= (bit);                                                     \
        }                                                                     \
    } while (0)

    EC_READ_HIGH(EC_INPUT_X_HOME, X_HOME);
    EC_READ_HIGH(EC_INPUT_X_END, X_END);
    EC_READ_HIGH(EC_INPUT_Y_HOME, Y_HOME);
    EC_READ_HIGH(EC_INPUT_Y_END, Y_END);
    EC_READ_HIGH(EC_INPUT_Z_UP, Z_UP);
    EC_READ_HIGH(EC_INPUT_Z_DOWN, Z_DOWN);
    EC_READ_HIGH(EC_INPUT_ESTOP_FB, ESTOP_FB);
    EC_READ_HIGH(EC_INPUT_START, START_SIG);
    EC_READ_HIGH(EC_INPUT_MANUAL_RESET, MANUAL_RESET_SIG);
    /* Fail closed until POWER_PERMISSION is assigned to a real GPIO in CubeMX.
     * With no mapping, this bit remains low in raw_mask, therefore it is active
     * in active_mask and startup cannot pass the power-permission gate. */
    /* EC_READ_HIGH(EC_INPUT_POWER_PERMISSION, POWER_PERMISSION); */

#undef EC_READ_HIGH
    return raw;
}

static TIM_HandleTypeDef *step_timer_for_axis(ec_axis_t axis)
{
    switch (axis) {
    case EC_AXIS_X: return &htim8;
    case EC_AXIS_Y: return &htim4;
    default: return NULL;
    }
}

/* Array slot (X=0, Y=1) and active-mask bit for a stepper axis. Callers
 * guarantee axis is EC_AXIS_X or EC_AXIS_Y. */
static uint32_t counted_slot(ec_axis_t axis)
{
    return (axis == EC_AXIS_X) ? 0U : 1U;
}

static uint8_t counted_bit(ec_axis_t axis)
{
    return (axis == EC_AXIS_X) ? UINT8_C(0x01) : UINT8_C(0x02);
}

/* Reverse mapping: which stepper axis a step timer's update interrupt
 * belongs to. Returns EC_AXIS_NONE for non-step timers. */
static ec_axis_t axis_for_step_timer(TIM_HandleTypeDef *htim)
{
    if ((htim != NULL) && (htim->Instance == htim8.Instance)) return EC_AXIS_X;
    if ((htim != NULL) && (htim->Instance == htim4.Instance)) return EC_AXIS_Y;
    return EC_AXIS_NONE;
}

static void stop_counted_axis(ec_axis_t axis)
{
    TIM_HandleTypeDef *timer;
    uint8_t bit = counted_bit(axis);
    uint32_t slot = counted_slot(axis);

    if ((counted_active_mask & bit) == 0U) return;
    timer = step_timer_for_axis(axis);
    if (timer != NULL) {
        (void)HAL_TIM_PWM_Stop(timer, TIM_CHANNEL_1);
        __HAL_TIM_DISABLE_IT(timer, TIM_IT_CC1);
        __HAL_TIM_DISABLE_IT(timer, TIM_IT_UPDATE);
    }
    counted_active_mask &= (uint8_t)~bit;
    counted_remaining[slot] = 0U;
    counted_total[slot] = 0U;
}

static void stop_all_counted(void)
{
    stop_counted_axis(EC_AXIS_X);
    stop_counted_axis(EC_AXIS_Y);
}

void ec_board_enter_safe_state(void)
{
    ec_step_port_stop_all();

    ec_barrier_port_stop();
    ec_servo_port_stop_z();

    ec_step_port_disable_all();
    HAL_GPIO_WritePin(LIGHT_EN_GPIO_Port, LIGHT_EN_Pin, GPIO_PIN_RESET);
}

void ec_board_poll_inputs(uint32_t now_ms)
{
    uint16_t raw = read_raw_inputs();
    if (input_filter_initialized == 0U) {
        ec_inputs_init(&input_filter, raw, now_ms);
        input_filter_initialized = 1U;
    } else {
        ec_inputs_update(&input_filter, raw, now_ms);
    }

    input_snapshot.raw_mask = raw;
    input_snapshot.stable_mask = ec_inputs_stable_mask(&input_filter);
    input_snapshot.active_mask = ec_inputs_active_mask(&input_filter);
}

ec_input_snapshot_t ec_board_read_inputs(void)
{
    return input_snapshot;
}

bool ec_step_port_start(ec_axis_t axis, uint32_t frequency_hz)
{
    TIM_HandleTypeDef *timer;
    uint32_t period;

    if ((frequency_hz != UINT32_C(10)) &&
        (frequency_hz != UINT32_C(100))) return false;
    timer = step_timer_for_axis(axis);
    if (timer == NULL) return false;

    /* TIM4/TIM8/TIM9 use a 100 kHz timer clock (PSC=159). */
    period = (EC_STEP_TIMER_HZ / frequency_hz) - 1U;
    __HAL_TIM_SET_AUTORELOAD(timer, period);
    __HAL_TIM_SET_COUNTER(timer, 0U);
    __HAL_TIM_SET_COMPARE(timer, TIM_CHANNEL_1, (period + 1U) / 2U);
    return HAL_TIM_PWM_Start(timer, TIM_CHANNEL_1) == HAL_OK;
}

bool ec_step_port_start_counted(ec_axis_t axis, uint32_t frequency_hz,
                                uint32_t steps)
{
    TIM_HandleTypeDef *timer;
    uint32_t period;
    uint8_t bit;
    uint32_t slot;

    if ((axis != EC_AXIS_X) && (axis != EC_AXIS_Y)) {
        return false;
    }
    bit = counted_bit(axis);
    /* Re-entry guard (P2-5): refuse to re-arm an axis that already has a
     * counted run active, so a stray second start can't overwrite that axis's
     * counted state. The other axis may be active (the dual-axis case, driven
     * through ec_step_port_start_counted_xy). */
    if ((counted_active_mask & bit) != 0U) return false;
    if (steps == 0U) return false;
    if ((frequency_hz < EC_STEP_MIN_HZ) ||
        (frequency_hz > EC_STEP_MAX_HZ)) {
        return false;
    }
    timer = step_timer_for_axis(axis);
    if (timer == NULL) return false;

    slot = counted_slot(axis);
    period = (EC_STEP_TIMER_HZ / frequency_hz) - 1U;
    __HAL_TIM_SET_AUTORELOAD(timer, period);
    __HAL_TIM_SET_COUNTER(timer, 0U);
    __HAL_TIM_SET_COMPARE(timer, TIM_CHANNEL_1, (period + 1U) / 2U);
    __HAL_TIM_CLEAR_FLAG(timer, TIM_FLAG_UPDATE);

    counted_active_mask |= bit;
    counted_remaining[slot] = steps;
    counted_total[slot] = steps;

    if (HAL_TIM_PWM_Start(timer, TIM_CHANNEL_1) != HAL_OK) {
        counted_active_mask &= (uint8_t)~bit;
        counted_remaining[slot] = 0U;
        counted_total[slot] = 0U;
        ec_step_port_stop_all();
        return false;
    }
    __HAL_TIM_ENABLE_IT(timer, TIM_IT_UPDATE);
    return true;
}

bool ec_step_port_start_counted_xy(uint32_t x_steps, uint32_t x_frequency_hz,
                                   uint32_t y_steps, uint32_t y_frequency_hz)
{
    /* A dual-axis move needs both axes free; refuse if either is already
     * running a counted move. */
    if (counted_active_mask != 0U) return false;
    /* P0-FIX: Allow single-axis moves (x=0 for Y-only, y=0 for X-only).
     * Only reject when both are zero. */
    if ((x_steps == 0U) && (y_steps == 0U)) return false;
    if ((x_frequency_hz < EC_STEP_MIN_HZ) ||
        (x_frequency_hz > EC_STEP_MAX_HZ) ||
        (y_frequency_hz < EC_STEP_MIN_HZ) ||
        (y_frequency_hz > EC_STEP_MAX_HZ)) {
        return false;
    }

    /* Start X axis only if x_steps > 0 */
    if (x_steps > 0U) {
        if (!ec_step_port_start_counted(EC_AXIS_X, x_frequency_hz, x_steps)) {
            return false;
        }
    }
    /* Start Y axis only if y_steps > 0 */
    if (y_steps > 0U) {
        if (!ec_step_port_start_counted(EC_AXIS_Y, y_frequency_hz, y_steps)) {
            if (x_steps > 0U) {
                ec_step_port_stop_all();  /* Clean up X if Y fails */
            }
            return false;
        }
    }
    return true;
}

void ec_step_port_on_timer_period(TIM_HandleTypeDef *htim)
{
    ec_axis_t axis;
    uint8_t bit;
    uint32_t slot;

    if (counted_active_mask == 0U) return;
    axis = axis_for_step_timer(htim);
    if (axis == EC_AXIS_NONE) return;
    bit = counted_bit(axis);
    if ((counted_active_mask & bit) == 0U) return;  /* this axis not counting */
    slot = counted_slot(axis);

    /* Fast-path safety inhibit (P2-3): read the raw limit/ESTOP GPIO pins
     * directly (no debounce) so a triggered limit/ESTOP halts within one
     * step tick instead of waiting for the main-loop poll (~50ms worst).
     * Same active-low polarity as ec_inputs_active_mask. */
    if (ec_motion_inhibit_from_raw(read_raw_inputs())) {
        stop_all_counted();
        ec_step_port_disable_all();
        ec_motion_test_on_aborted();
        return;
    }

    if (counted_remaining[slot] > 0U) {
        counted_remaining[slot]--;
    }
    if (counted_remaining[slot] == 0U) {
        /* Runs in the TIM update ISR. HAL_TIM_PWM_Stop inside
         * stop_counted_axis may return HAL_BUSY if the main loop holds the
         * lock, but the safety fallback is ec_step_port_disable_all (direct
         * GPIO write) right after, which does not depend on the HAL lock. */
        stop_counted_axis(axis);
        /* Only signal completion + drop drivers once BOTH axes have finished
         * (the other axis may still be mid-run in a dual move). */
        if (counted_active_mask == 0U) {
            ec_step_port_disable_all();
            ec_motion_test_on_counted_done();
        }
    }
}

static bool barrier_start_channel(TIM_HandleTypeDef *timer,
                                  uint32_t channel, uint16_t pulse_us)
{
    if ((pulse_us == 0U) || (pulse_us > htim3.Init.Period)) return false;

    __HAL_TIM_SET_COUNTER(timer, 0U);
    __HAL_TIM_SET_COMPARE(timer, channel, pulse_us);
    return HAL_TIM_PWM_Start(timer, channel) == HAL_OK;
}

bool ec_barrier_port_start_mask(uint8_t channel_mask, uint16_t pulse_us)
{
    bool ok = true;

    if ((channel_mask == 0U) || (pulse_us == 0U) ||
        (pulse_us > htim3.Init.Period)) {
        return false;
    }

    ec_barrier_port_stop();
    if (((channel_mask & UINT8_C(0x01)) != 0U) &&
        !barrier_start_channel(&htim3, TIM_CHANNEL_3, pulse_us)) {
        ok = false;
    }
    if (((channel_mask & UINT8_C(0x02)) != 0U) &&
        !barrier_start_channel(&htim3, TIM_CHANNEL_4, pulse_us)) {
        ok = false;
    }
    if (((channel_mask & UINT8_C(0x04)) != 0U) &&
        !barrier_start_channel(&htim10, TIM_CHANNEL_1, pulse_us)) {
        ok = false;
    }
    if (((channel_mask & UINT8_C(0x08)) != 0U) &&
        !barrier_start_channel(&htim11, TIM_CHANNEL_1, pulse_us)) {
        ok = false;
    }

    if (!ok) {
        ec_barrier_port_stop();
        return false;
    }
    return true;
}

void ec_barrier_port_stop(void)
{
    (void)HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);
    (void)HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_4);
    (void)HAL_TIM_PWM_Stop(&htim10, TIM_CHANNEL_1);
    (void)HAL_TIM_PWM_Stop(&htim11, TIM_CHANNEL_1);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0U);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0U);
    __HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1, 0U);
    __HAL_TIM_SET_COMPARE(&htim11, TIM_CHANNEL_1, 0U);
}

uint32_t ec_barrier_port_now_ms(void)
{
    return HAL_GetTick();
}

/* Z-axis lift servo: TIM2_CH4 = PB11, the former WRIST_PWM channel. Shares
 * TIM2's 50 Hz servo period with the gripper (TIM2_CH3). */
bool ec_servo_port_start_z(uint16_t pulse_us)
{
    if ((pulse_us == 0U) || (pulse_us > htim2.Init.Period)) return false;

    __HAL_TIM_SET_COUNTER(&htim2, 0U);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulse_us);
    return HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4) == HAL_OK;
}

void ec_servo_port_stop_z(void)
{
    (void)HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_4);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, 0U);
}

uint32_t ec_servo_port_now_ms(void)
{
    return HAL_GetTick();
}

bool ec_step_port_set_direction(ec_axis_t axis, ec_direction_t direction)
{
    GPIO_PinState state = (direction == EC_DIRECTION_1) ?
                          GPIO_PIN_SET : GPIO_PIN_RESET;

    switch (axis) {
    case EC_AXIS_X:
        HAL_GPIO_WritePin(DIR_X_GPIO_Port, DIR_X_Pin, state);
        return true;
    case EC_AXIS_Y:
        HAL_GPIO_WritePin(DIR_Y_GPIO_Port, DIR_Y_Pin, state);
        return true;
    default:
        return false;
    }
}

bool ec_step_port_enable_axis(ec_axis_t axis)
{
    ec_step_port_disable_all();
    switch (axis) {
    case EC_AXIS_X:
        HAL_GPIO_WritePin(ENABLE_X_GPIO_Port, ENABLE_X_Pin, GPIO_PIN_RESET);
        return true;
    case EC_AXIS_Y:
        HAL_GPIO_WritePin(ENABLE_Y_GPIO_Port, ENABLE_Y_Pin, GPIO_PIN_RESET);
        return true;
    default:
        return false;
    }
}

bool ec_step_port_enable_xy(void)
{
    ec_step_port_disable_all();
    HAL_GPIO_WritePin(ENABLE_X_GPIO_Port, ENABLE_X_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ENABLE_Y_GPIO_Port, ENABLE_Y_Pin, GPIO_PIN_RESET);
    return true;
}

void ec_step_port_stop_all(void)
{
    stop_all_counted();
    (void)HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_1);
    (void)HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
}

void ec_step_port_disable_all(void)
{
    HAL_GPIO_WritePin(ENABLE_X_GPIO_Port, ENABLE_X_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(ENABLE_Y_GPIO_Port, ENABLE_Y_Pin, GPIO_PIN_SET);
}

uint32_t ec_step_port_now_ms(void)
{
    return HAL_GetTick();
}

uint32_t ec_step_port_counted_remaining(void)
{
    /* Sum across both axes. Single-axis callers only ever have one axis
     * active, so for them this equals that axis's remaining. */
    return counted_remaining[0] + counted_remaining[1];
}

uint32_t ec_step_port_counted_target(void)
{
    return counted_total[0] + counted_total[1];
}

uint32_t ec_step_port_counted_remaining_for(ec_axis_t axis)
{
    if ((axis != EC_AXIS_X) && (axis != EC_AXIS_Y)) return 0U;
    return counted_remaining[counted_slot(axis)];
}

uint32_t ec_step_port_counted_target_for(ec_axis_t axis)
{
    if ((axis != EC_AXIS_X) && (axis != EC_AXIS_Y)) return 0U;
    return counted_total[counted_slot(axis)];
}

bool ec_step_port_counted_all_done(void)
{
    return counted_active_mask == 0U;
}

bool ec_group_port_set_direction(ec_axis_t axis, ec_direction_t direction)
{
    return ec_step_port_set_direction(axis, direction);
}

bool ec_group_port_enable_xy(void)
{
    ec_step_port_disable_all();
    HAL_GPIO_WritePin(ENABLE_X_GPIO_Port, ENABLE_X_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ENABLE_Y_GPIO_Port, ENABLE_Y_Pin, GPIO_PIN_RESET);
    return true;
}

bool ec_group_port_start_step(ec_axis_t axis, uint32_t frequency_hz)
{
    return ec_step_port_start(axis, frequency_hz);
}

bool ec_group_port_start_servo(uint16_t pulse_us)
{
    return ec_servo_port_start_z(pulse_us);
}

void ec_group_port_stop_all(void)
{
    ec_step_port_stop_all();
    ec_servo_port_stop_z();
    ec_step_port_disable_all();
}

uint32_t ec_group_port_now_ms(void)
{
    return HAL_GetTick();
}

void ec_safety_port_stop_all(void)
{
    ec_step_port_stop_all();
    ec_servo_port_stop_z();
    ec_barrier_port_stop();
}

void ec_safety_port_disable_drivers(void)
{
    ec_step_port_disable_all();
}

void ec_safety_port_inhibit_power(void)
{
    /* ESTOP_FB is feedback only; dangerous power is cut by external hardware. */
    ec_servo_port_stop_z();
    ec_barrier_port_stop();
    ec_step_port_disable_all();
}

void ec_diag_port_write(const char *text)
{
    size_t length = strlen(text);
    uint32_t timeout_ms;

    if (length > UINT16_MAX) return;
    /* 115200 8N1 -> 11520 bytes/s. Allow 2x the send time + 10 ms floor so
     * STATUS/HELP (~350 B) are not truncated by a fixed 20 ms timeout. */
    timeout_ms = (uint32_t)((length * 2000UL) / 11520UL) + 10UL;
    (void)HAL_UART_Transmit(&huart2, (uint8_t *)text, (uint16_t)length,
                            timeout_ms);
}

void ec_board_uart_transmit(const uint8_t *data, size_t length)
{
    uint32_t timeout_ms;

    if ((data == NULL) || (length == 0U) || (length > UINT16_MAX)) return;
    /* Same timing model as ec_diag_port_write; binary frames are <= 64 B. */
    timeout_ms = (uint32_t)((length * 2000UL) / 11520UL) + 10UL;
    (void)HAL_UART_Transmit(&huart2, (uint8_t *)data, (uint16_t)length,
                            timeout_ms);
}

void ec_board_uart_start_rx(void)
{
    uart_rx_head = 0U;
    uart_rx_tail = 0U;
    (void)HAL_UART_Receive_IT(&huart2, &uart_main_rx_byte, 1U);
}

void ec_board_uart_rx_callback(UART_HandleTypeDef *huart)
{
    uint32_t next_head;

    if ((huart != NULL) && (huart->Instance == USART2)) {
        /* P0-FIX: ISR only writes byte to ring buffer, does NOT call app logic.
         * Main loop will poll ec_board_uart_rx_available() and process bytes. */
        next_head = (uart_rx_head + 1U) & UART_RX_RING_MASK;
        if (next_head != uart_rx_tail) {
            /* Ring has space: write byte and advance head */
            uart_rx_ring[uart_rx_head] = uart_main_rx_byte;
            uart_rx_head = next_head;
        }
        /* else: ring full, drop byte (overrun). Alternative: halt RX until drained. */
        (void)HAL_UART_Receive_IT(&huart2, &uart_main_rx_byte, 1U);
    }
}

bool ec_board_uart_rx_available(void)
{
    return uart_rx_head != uart_rx_tail;
}

uint8_t ec_board_uart_rx_read(void)
{
    uint8_t byte;

    /* Caller guarantees ec_board_uart_rx_available() returned true */
    byte = uart_rx_ring[uart_rx_tail];
    uart_rx_tail = (uart_rx_tail + 1U) & UART_RX_RING_MASK;
    return byte;
}
